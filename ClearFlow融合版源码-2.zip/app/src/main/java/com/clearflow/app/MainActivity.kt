package com.clearflow.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val sharedText = mutableStateOf("")
    override fun onCreate(b: Bundle?) { super.onCreate(b); readShare(intent); render() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); readShare(intent); render() }
    private fun readShare(i: Intent?) { if (i?.action == Intent.ACTION_SEND) sharedText.value = i.getStringExtra(Intent.EXTRA_TEXT).orEmpty() }
    private fun render() { setContent { ClearFlowApp(sharedText.value) } }
}

@Composable
fun ClearFlowApp(shared: String) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var events by remember { mutableStateOf(TagStore.loadEvents(context).ifEmpty { DemoData.events.toList() }) }
    LaunchedEffect(events) { TagStore.saveEvents(context, events) }
    val tabs = listOf("首页", "收纳箱", "比价", "偏好", "隐私")
    Scaffold(bottomBar = { NavigationBar { tabs.forEachIndexed { i, t -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) }) } } }) { p ->
        Column(Modifier.padding(p).padding(18.dp)) {
            Text("清醒流 ClearFlow", style = MaterialTheme.typography.headlineSmall)
            Text("本机优先 · 标签学习 · 可回溯 · 默认不删除", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (shared.isNotBlank()) Card(Modifier.fillMaxWidth().padding(top = 10.dp)) { Column(Modifier.padding(14.dp)) { Text("已收到分享内容", style = MaterialTheme.typography.titleMedium); Text(shared.take(240)); Text("可以切换到‘比价’页继续整理。", color = MaterialTheme.colorScheme.onSurfaceVariant) } }
            Spacer(Modifier.height(16.dp))
            when (tab) {
                0 -> Home(events, { tab = 2 }, { tab = 1 })
                1 -> Shelved(events) { e ->
                    TagStore.feedback(context, e, positive = true, explicit = true)
                    events = events.map { if (it.id == e.id) it.copy(restored = true, action = "我其实要", dismissed = false, reason = "已恢复；已增强相关标签") else it }
                }
                2 -> Compare()
                3 -> Prefs(context, events)
                4 -> Privacy()
            }
        }
    }
}

@Composable
fun Home(events: List<PopupEvent>, onCompare: () -> Unit, onShelve: () -> Unit) {
    val shelved = events.count { it.dismissed && !it.restored && !it.explored }
    val explored = events.count { it.explored }
    Text("把时间留给真正重要的事。", style = MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(14.dp))
    Card { Column(Modifier.padding(18.dp)) { Text("今日值得看", style = MaterialTheme.typography.titleLarge); Text("${events.size - shelved} 条保留 · $shelved 条收纳 · $explored 条探索样本", style = MaterialTheme.typography.bodyLarge); Text("标签会根据打开、划走和‘我其实要’持续更新。") } }
    Spacer(Modifier.height(12.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = onCompare) { Text("开始比价") }; OutlinedButton(onClick = onShelve) { Text("查看收纳箱") } }
}

@Composable
fun Shelved(events: List<PopupEvent>, restore: (PopupEvent) -> Unit) {
    Text("收纳箱", style = MaterialTheme.typography.headlineSmall)
    Text("所有内容都可恢复；恢复会给相关标签强正反馈。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(10.dp)); val shelved = events.filter { !it.restored && it.dismissed && !it.explored }
    if (shelved.isEmpty()) Text("暂无收纳内容")
    LazyColumn { items(shelved, key = { it.id }) { e -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { ListItem({ Text(e.title) }, supportingContent = { Text("${e.app} · ${e.category} · ${e.reason}") }, trailingContent = { Button(onClick = { restore(e) }) { Text("我其实要") } }) } } }
}

@Composable
fun Compare() {
    Text("商品比较", style = MaterialTheme.typography.headlineSmall); Text("本地模拟报价；明确展示到手价、时效风险和规格差异。", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp))
    val offers = DemoData.offers; val best = offers[0]; val cheapest = offers.minBy { it.landedPrice }
    offers.forEach { o -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { ListItem({ Text("${o.platform} · ${o.merchant}") }, supportingContent = { Text("到手 ¥${"%.1f".format(o.landedPrice)} · P50/P90 ${o.etaP50}/${o.etaP90} 分钟 · ${o.matchLevel} · 更新于 ${o.priceTimestamp}") }, trailingContent = { if (o == best) Text("综合最优") else Text("查看") }) } }
    Spacer(Modifier.height(8.dp)); Text(PreferenceEngine.explanation(best, cheapest))
}

@Composable
fun Prefs(context: android.content.Context, events: List<PopupEvent>) {
    val tags = TagStore.loadTags(context).values.sortedByDescending { kotlin.math.abs(it.score) * it.confidence }
    Text("偏好与用户标签", style = MaterialTheme.typography.headlineSmall)
    Text("标签由本机行为学习；明确纠正的权重高于停留和划走。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(10.dp))
    if (tags.isEmpty()) Text("还没有足够证据，继续使用后会生成标签。")
    tags.take(12).forEach { t -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { ListItem({ Text(t.id) }, supportingContent = { Text("偏好 ${"%.2f".format(t.score)} · 置信度 ${"%.0f".format(t.confidence * 100)}% · ${t.evidence} 条证据") }) } }
    Spacer(Modifier.height(8.dp)); Text("探索样本：${events.count { it.explored }} 条；恢复样本：${events.count { it.restored }} 条。")
}

@Composable
fun Privacy() {
    val context = LocalContext.current
    Text("隐私与数据契约", style = MaterialTheme.typography.headlineSmall)
    Text("标签、通知摘要和反馈只保存在本机 SharedPreferences；当前版本不上传原文，也不会自动清除系统通知。", color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(10.dp)); Button(onClick = { context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }) { Text("打开系统通知授权") }
    Text("授权后，通知服务会读取标题、正文、来源包名和必要的系统元数据，用于本机标签与收纳。验证码、金融和聊天内容不会主动上传。")
}
