package com.clearflow.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.exp

data class PopupEvent(
    val id: String = "",
    val app: String,
    val title: String,
    val category: String,
    val price: String,
    val action: String,
    val dwellSeconds: Int,
    val dismissed: Boolean,
    val explored: Boolean = false,
    val restored: Boolean = false,
    val reason: String = ""
)

data class UserTag(
    val id: String,
    val score: Double,
    val confidence: Double,
    val evidence: Int,
    val locked: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

data class TagDecision(val action: String, val tags: List<String>, val confidence: Double, val reason: String)

object TagStore {
    private const val FILE = "clearflow_profile_v1"
    private const val TAGS = "tags"
    private const val EVENTS = "events"
    private fun prefs(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized fun loadTags(c: Context): MutableMap<String, UserTag> {
        val result = linkedMapOf<String, UserTag>()
        val raw = prefs(c).getString(TAGS, "[]") ?: "[]"
        runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val t = UserTag(o.getString("id"), o.getDouble("score"), o.getDouble("confidence"), o.getInt("evidence"), o.optBoolean("locked"), o.optLong("updatedAt"))
                result[t.id] = t
            }
        }
        return result
    }
    @Synchronized fun saveTags(c: Context, tags: Map<String, UserTag>) {
        val a = JSONArray(); tags.values.forEach { t -> a.put(JSONObject().apply { put("id", t.id); put("score", t.score); put("confidence", t.confidence); put("evidence", t.evidence); put("locked", t.locked); put("updatedAt", t.updatedAt) }) }
        prefs(c).edit().putString(TAGS, a.toString()).apply()
    }
    @Synchronized fun loadEvents(c: Context): MutableList<PopupEvent> {
        val out = mutableListOf<PopupEvent>(); val raw = prefs(c).getString(EVENTS, "[]") ?: "[]"
        runCatching { val a = JSONArray(raw); for (i in 0 until a.length()) { val o=a.getJSONObject(i); out += PopupEvent(o.optString("id"),o.optString("app"),o.optString("title"),o.optString("category"),o.optString("price"),o.optInt("dwellSeconds"),o.optBoolean("dismissed"),o.optBoolean("explored"),o.optBoolean("restored"),o.optString("reason")) } }
        return out
    }
    @Synchronized fun saveEvents(c: Context, events: List<PopupEvent>) {
        val a=JSONArray(); events.takeLast(200).forEach { e -> a.put(JSONObject().apply { put("id",e.id);put("app",e.app);put("title",e.title);put("category",e.category);put("price",e.price);put("dwellSeconds",e.dwellSeconds);put("dismissed",e.dismissed);put("explored",e.explored);put("restored",e.restored);put("reason",e.reason) }) }; prefs(c).edit().putString(EVENTS,a.toString()).apply()
    }
    fun feedback(c: Context, event: PopupEvent, positive: Boolean, explicit: Boolean) {
        val tags=loadTags(c); val ids=TagEngine.tagsFor(event); val delta=if (positive) 0.16 else -0.14
        ids.forEach { id -> val old=tags[id] ?: UserTag(id,0.0,0.0,0); val n=(old.evidence+1); val confidence=1.0-exp(-n/8.0); val score=(old.score+delta*(if(explicit)2.5 else 1.0)).coerceIn(-1.0,1.0); tags[id]=old.copy(score=score,confidence=confidence,evidence=n,updatedAt=System.currentTimeMillis()) }; saveTags(c,tags)
    }
}

object TagEngine {
    fun tagsFor(e: PopupEvent): List<String> {
        val text=(e.category+" "+e.title).lowercase(); val out=mutableListOf<String>()
        if (listOf("促销","优惠","抽奖","广告","满减","直播").any { text.contains(it) }) out += "noise.promotion"
        if (listOf("工作","会议","项目","日报","任务").any { text.contains(it) }) out += "intent.work"
        if (listOf("物流","快递","配送","到货").any { text.contains(it) }) out += "intent.delivery"
        if (listOf("知识","教程","设计","旅行","学习").any { text.contains(it) }) out += "topic.knowledge"
        if (listOf("验证码","安全","登录","紧急","告警").any { text.contains(it) }) out += "urgency.security"
        return if(out.isEmpty()) listOf("topic.other") else out
    }
    fun decide(e: PopupEvent, tags: Map<String,UserTag>): TagDecision {
        val ids=tagsFor(e); val matched=ids.mapNotNull{tags[it]}; val strongest=matched.maxByOrNull{ kotlin.math.abs(it.score)*it.confidence }
        val c=strongest?.confidence ?: 0.0; val s=strongest?.score ?: 0.0
        if (ids.any{"urgency.security"==it || "intent.work"==it && e.dwellSeconds>0}) return TagDecision("KEEP",ids,c,"安全或工作相关内容优先保留")
        if (s < -0.80 && c >= .85) return TagDecision("REMOVE",ids,c,"用户对该类内容持续负反馈")
        if (s < -0.45 && c >= .55) return TagDecision("SHELVE",ids,c,"根据历史偏好收纳，可在收纳箱恢复")
        if (c < .55) return TagDecision("EXPLORE",ids,c,"证据不足，保留为探索样本")
        return TagDecision("KEEP",ids,c,"未达到收纳或清除阈值")
    }
}
data class ProductOffer(
    val platform: String,
    val merchant: String,
    val unitPrice: Double,
    val netQty: Double,
    val quantityUnit: String,
    val itemCount: Int,
    val deliveryFee: Double,
    val etaP50: Int,
    val etaP90: Int,
    val service: String,
    val priceTimestamp: String,
    val matchLevel: String
) { val landedPrice: Double get() = unitPrice * itemCount + deliveryFee; val riskEta: Double get() = etaP50 + 0.5 * (etaP90 - etaP50) }
data class ChoiceLog(val requestId:String,val candidates:String,val chosenId:String,val sceneTag:String,val timestamp:String)
object DemoData {
    val events = mutableListOf(
        PopupEvent("demo-1","淘宝","复杂满减活动","促销","¥399","立即划走",1,true,reason="重复促销，已收纳，可恢复"),
        PopupEvent("demo-2","抖音","降噪耳机直降","电子产品","¥499","已加购",8,false,reason="高意图：已加购，永不隐藏"),
        PopupEvent("demo-3","知乎","设计软件优惠","设计工具","¥499","已点击",14,false,explored=true,reason="探索样本：用于校准偏好")
    )
    val offers = listOf(
        ProductOffer("京东","官方自营",499.0,1.0,"件",1,0.0,24,38,"售后稳定","刚刚","同款"),
        ProductOffer("天猫","官方旗舰店",509.0,1.0,"件",1,0.0,26,42,"售后稳定","刚刚","同款"),
        ProductOffer("抖音","直播间",465.0,1.0,"件",1,0.0,48,80,"规则较多","7 小时前","疑似规格不同")
    )
}
object PreferenceEngine {
    fun interest(e: PopupEvent): Int = when { e.restored -> 4; e.action == "已购买" -> 8; e.action == "已加购" -> 5; e.action == "已收藏" -> 4; e.action == "已点击" -> 2; e.dismissed -> -3; else -> 0 } + if (e.dwellSeconds >= 8) 2 else 0
    fun shouldShelve(e:PopupEvent):Boolean = !e.restored && e.dismissed && !e.explored && e.action == "立即划走"
    fun explanation(best:ProductOffer, cheapest:ProductOffer):String = "归因：预计风险调整后 ${best.riskEta.toInt()} 分钟送达。\n对比：比最低价贵 ¥${"%.1f".format(best.landedPrice-cheapest.landedPrice)}，但预计快 ${cheapest.riskEta.toInt()-best.riskEta.toInt()} 分钟。\n反事实：如果愿意多等 ${best.riskEta.toInt()-cheapest.riskEta.toInt()} 分钟，可省 ¥${"%.1f".format(best.landedPrice-cheapest.landedPrice)}。"
}
object OfferNormalizer {
    fun unitPrice(total:Double, count:Int, size:Double):Double = if(count>0 && size>0) total/(count*size) else total
    fun matchLevel(a:ProductOffer,b:ProductOffer):String = when { a.quantityUnit!=b.quantityUnit || a.netQty!=b.netQty || a.itemCount!=b.itemCount -> "规格不同"; kotlin.math.abs(a.landedPrice-b.landedPrice)/a.landedPrice < .4 -> "同款"; else -> "同类参考" }
}
