package com.clearflow.app
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class ClearFlowNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val id = "${sbn.key}:${sbn.notification.`when`}:${sbn.id}"
        val old = TagStore.loadEvents(this)
        if (old.any { it.id == id }) return
        val event = PopupEvent(id, packageName, title, inferCategory(title, text), "", "收到通知", 0, false, reason = "通知已记录；默认不删除")
        val tags = TagStore.loadTags(this)
        val decision = TagEngine.decide(event, tags)
        val stored = when (decision.action) {
            "SHELVE" -> event.copy(dismissed = true, reason = "${decision.reason}（${decision.tags.joinToString()}）")
            "EXPLORE" -> event.copy(explored = true, reason = decision.reason)
            else -> event.copy(reason = decision.reason)
        }
        TagStore.saveEvents(this, old + stored)
        // 安全默认：此版本只收纳，不调用 cancelNotification，避免误删系统通知。
    }

    private fun inferCategory(title: String, text: String): String {
        val v = "$title $text"
        return when {
            listOf("验证码", "安全", "登录", "告警").any { v.contains(it) } -> "安全"
            listOf("会议", "工作", "任务", "项目").any { v.contains(it) } -> "工作"
            listOf("优惠", "促销", "广告", "直播", "满减").any { v.contains(it) } -> "促销"
            listOf("快递", "物流", "配送", "到货").any { v.contains(it) } -> "物流"
            else -> "其他"
        }
    }
}
