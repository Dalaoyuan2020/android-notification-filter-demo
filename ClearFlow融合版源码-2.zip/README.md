# 清醒流 ClearFlow Android 本地 MVP

这版按照《清醒流-改进与算法精度提升方案》落地了安全优先的本地闭环：

- 默认“收纳”而不是删除：收纳箱可回溯、可恢复；高意图内容不收纳；探索样本标记 `explored`。
- 到手价与风险调整 ETA：展示配送 P50/P90、时间戳、规格差异和解释性的归因/对比/反事实理由。
- 同款基础规则：件数、净量、单位和规格先归一化；规格不一致显示“规格不同”。
- 偏好纠正：`我其实要` 会恢复内容；模型记录兴趣分数和探索样本。
- 隐私：本机优先；通知授权单独打开，默认不读取聊天、验证码、金融、通讯录、相册和定位。
- 不接爬虫：比价数据当前是模拟数据，后续接官方开放/联盟接口或用户主动分享内容。

## 在 Android Studio 运行

1. 用 Android Studio 打开项目根目录。
2. 等待 Gradle Sync 完成；使用 Android Studio 自带 JDK 17。
3. 连接开启 USB 调试的 Android 手机。
4. 选择 `app` 配置并点击 Run。
5. 在“隐私”页面按需打开系统通知授权。未授权也可以使用首页、收纳箱、比价和偏好页面。

## GitHub 开源参考

本项目仅使用 AndroidX/Jetpack 官方依赖。后续扩展可参考并逐项核对许可证：

- https://github.com/android/platform-samples （官方平台能力示例）
- https://github.com/android/architecture-samples （Android 分层与测试示例）
- https://github.com/android/nowinandroid （Jetpack Compose 与现代 Android 架构示例）

没有复制第三方业务代码；通知监听、官方比价 API 和 OCR 接入必须单独审查权限、协议和许可证。

## 当前边界

当前是可运行的本地 MVP，不承诺自动拦截所有第三方弹窗或实时价格。真实通知监听必须新增 `NotificationListenerService` 并取得系统授权；真实比价必须通过用户分享或合法开放接口接入。
